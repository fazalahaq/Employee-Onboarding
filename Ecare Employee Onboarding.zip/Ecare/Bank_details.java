package Ecare;
import com.microsoft.playwright.Page;

public class Bank_details {

	public void bank(Page page) throws InterruptedException {
/*
        //Search employee
        Thread.sleep(2000);
        page.fill("//*[@placeholder=\"Search Employee Name/Department/Employee ID\"]", "Suresh Kumar Gupta");
        Thread.sleep(2000);
        //Click on view Button
        //page.waitForSelector("(//*[@type=\"search\"])[2]", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
        page.click("//tr[2]/td[16]/div/div");
        
        //Click on the edit Button
        page.click("(//button[@type=\"button\"])[1]");
 */       
        //Click on Bank Details Tab
        page.click("//*[contains(text(),'Bank Details')]");
        
       
        //Select Salary template
        page.fill("(//*[@class=\"ant-select-selection-search-input\"])[10]", "test template new");
        page.keyboard().press("Enter");
		
        
        // Enter IFSC Code
        page.fill("//*[@placeholder=\"Enter IFSC Code\"]", "SBIN0000140");
        Thread.sleep(5000);
        
        //Enter account Number
        page.fill("//*[@placeholder=\"Enter Account Number\"]", "20389628603");
        
        //Re-enter The account number
        page.fill("//*[@placeholder=\"Re-Enter Account Number\"]", "20389628603");
        
        //Assign Shift
        page.click("//button[@type='button'] / span[contains(text(),'Assign Shift')]");
        
        //Click on Assign PopUp
        page.click("(//button[@type='button'] / span[contains(text(),'Assign')])[2]");
        
        //Click on save
        page.click("(//button[@type=\"primary\"])[4]");
	}

}
