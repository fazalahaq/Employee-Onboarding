package Ecare;

import java.util.List;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Main {

		public static void main(String[] args) throws InterruptedException {
			Playwright playwright = Playwright.create();
			Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setArgs(List.of("--start-maximized")));
			BrowserContext context = browser.newContext(new Browser.NewContextOptions().setViewportSize(null));		
			Page page = context.newPage();	
			page.navigate("https://devui-ecare.mightcode.com/login");
			
			//Login
	        page.fill("//input[@id='basic_email']","hrm1");
	        page.fill("//*[@id=\"basic_password\"]","Test@123");
	        page.click("//button[@type=\"submit\"]");	        
	        
	        
	       // String DOB = "04/04/2001";
	        String name = "ravii kumar sharma";
	        String MobilePer = "8854232911";
	        String emailPer = "test32@gmail.com";
	        String emailOff = "test22@mightcode.com";
	        //String search = "ravii kumar sharma";
	        
	        Personal_Details PerDel = new Personal_Details();
	        PerDel.personal(page, name, MobilePer,emailPer );
	        Thread.sleep(2000);
	        
	        Professional_details ProfDel = new Professional_details();
	        ProfDel.professional(page, emailOff, name);
	        
	        Salary sal = new Salary();
	        sal.salary(page);
	        
	        Bank_details bnk = new Bank_details();
	        bnk.bank(page);
	        
	}

}
