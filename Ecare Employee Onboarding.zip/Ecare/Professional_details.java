package Ecare;

import java.nio.file.Path;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;

public class Professional_details {

	public void professional(Page page, String emailOff, String name ) throws InterruptedException {
        page.click("//*[@href=\"/hr/employee-listing\"]"); //click on employee at side menu
       // Search employee
       Thread.sleep(2000);
        page.fill("//*[@placeholder=\"Search Employee Name/Department/Employee ID\"]", name);
        Thread.sleep(2000);
        //Click on view Button
        //page.waitForSelector("(//*[@type=\"search\"])[2]", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
        page.click("//tr[2]/td[16]/div/div");
        
        //Click on the edit Button
        page.click("(//button[@type=\"button\"])[1]");
        
        //Click on Professional Tab
        page.click("//*[contains(text(),'Professional Information')]");
        
        //Radio button Job Type
        page.waitForSelector("(//*[@type=\"search\"])[15]", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
        page.click("//*[@value=\"Contractual\"]");
        
        //Selecting the Date of Joining
        page.click("//*[@name=\"join_date\"]"); //Open Calendar
        page.click("//*[@class=\"ant-picker-cell ant-picker-cell-in-view ant-picker-cell-today\"]");//Select Todays date
        
        //Probation Check box
        page.click("//*[@name=\"is_probation_period\"]");
        //click on the probation edit button
        page.click("(//*[@class=\"h-auto flex cursor-pointer\"])[1]");
        //Enter the probation Period in the days
        page.fill("//input[@name=\"probation_period_days\"]", "60");
        
        //Notice Period Checkbox
        page.click("//input[@name=\"is_notice_period\"]");
        //Click on the notice period pencil
        page.click("(//div[@class=\"h-auto flex cursor-pointer\"])[2]");
        //Enter the number in notice period text box
        page.fill("//input[@name=\"notice_period_days\"]", "60");
        
        //Department Dropdown
        page.fill("(//input[@type=\"search\"])[9]", "Blood Bank");
        page.keyboard().press("Enter");
        
        //Role
        page.fill("(//input[@type=\"search\"])[10]", "HR Manager");
        page.keyboard().press("Enter");
        
        //Designation
        page.waitForTimeout(3000);
        page.fill("(//input[@type=\"search\"])[11]", "HR Manager");
        page.keyboard().press("Enter");
        
        //Mobile Number code Drop down
//        page.fill("(//input[@type=\"search\"])[12]", "+91");
//        page.keyboard().press("Enter");
        
        //Enter mobile number
        page.fill("//*[@name=\"professional_phone\"]", "8799191157");
        
        //Email
        page.fill("//*[@name=\"professional_email\"]", emailOff);
        
        //Experience Years
        page.fill("(//*[@type=\"search\"])[13]", "2");      
        page.keyboard().press("Enter");
        
        //Experience Months
        page.fill("(//*[@type=\"search\"])[14]", "3");
        page.keyboard().press("Enter");
        
        //Job Type
        page.waitForSelector("(//*[@type=\"search\"])[15]", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
        page.fill("(//*[@type=\"search\"])[15]", "Contract-Full Time");
        page.keyboard().press("Enter");
        
        //HOD
        page.fill("(//*[@type=\"search\"])[16]", "Vivek Yadav  (Front Office)");
        page.keyboard().press("Enter");
        
        //Credentials
        page.fill("//*[@placeholder=\"Enter Username\"]", "viveky@mightcode.com");
        
        //Click on Generate
        page.click("//*[contains(text(),'Generate')]");
        
        //Enter the Qualification
        page.fill("//*[@placeholder=\"Enter Your Qualification\"]", "MCA");
        
        //Click Qualification (From)
        page.click("(//*[@class=\"ant-picker ant-picker-middle ant-picker-outlined css-1lfmcmr block\"])[3]");
        //click on the from year button
        page.locator("//div[12]/div/div/div/div/div[1]/div/div[1]/div/button[2]").click();
              
        //Click on the Previous Year Button
        Thread.sleep(2000);
        page.locator("(//button[@aria-label='super-prev-year'])[2]").click();            
        
        //Select the year 2017
        page.click("//*[@title=\"2017\"]");
        //Select the Month April
        page.click("//*[@title=\"2017-04\"]");
        //Select the day
        page.click("//*[@title=\"2017-04-08\"]");
        
        
        //Click on the Qualification (To)
        page.click("//*[@name=\"qualification.toDate\"]");
        
        //Click on the Year (To)
        //page.click("//div[13]/div/div/div/div/div[1]/div/div[1]/div/button[2]");
        //page.click("(//*[@class=\"ant-picker-year-btn\"])[3]");
        //page.click("//*[@class=\"ant-picker-year-btn\"]  [contains(text(),'2025')]");
        page.click("(//*[@aria-label='year panel' and contains(text(), '2025')])[2]");
        //Click on the Backward button Year to choose 2020
        page.click("//td[@title='2020']");
        
        //Select the Month (To)
        page.click("//td[@title='2020-05']");
        
        //Select the Day (To)
        page.click("//*[@title='2020-05-07']");
        
        //Upload doc in Education //Click on Browse
        //page.locator("(//button[@type=\"primary\"])[4]").click();
        Thread.sleep(2000);
        page.locator("(//input[@name='file'])[2]").setInputFiles(Path.of("C:\\Users\\Unicode\\Documents\\Lightshot\\Screenshot_1.png"));
        
        //Click + Button for Upload
        page.click("(//span[@aria-label=\"plus\"])[3]");
        
        //Save the Details
        page.click("//button[@name=\"Save\"]");

        
        
        	
		
	}

}
