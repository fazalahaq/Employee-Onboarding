package Ecare;

import com.microsoft.playwright.Page;

public class Salary {


		public void salary(Page page) throws InterruptedException {
/*
	        //Search employee
	        Thread.sleep(2000);
	        page.fill("//*[@placeholder=\"Search Employee Name/Department/Employee ID\"]", "Suresh Kumar Gupta");
	        Thread.sleep(2000);
	        //Click on view Button
	        //page.waitForSelector("(//*[@type=\"search\"])[2]", new Page.WaitForSelectorOptions().setState(WaitForSelectorState.VISIBLE));
	        page.click("//tr[2]/td[16]/div/div");
	        
	        //Click on the edit Button
	        page.click("(//button[@type=\"button\"])[1]");
*/	        
	        //Click on Salary Tab
	        page.click("//*[contains(text(),'Salary Annexure')]");
	        
	        page.reload();	       
	        page.click("//*[contains(text(),'Salary Annexure')]");

	        //Select Salary template
	        Thread.sleep(3000);
//	        page.fill("(//input[@class=\"ant-select-selection-search-input\"])[9]", "test template new");
	        page.fill("//input[@id='rc_select_8']", "Test template new");
	        Thread.sleep(2000);
	        page.keyboard().press("Enter");
	        
	        //UAN No.
	        page.fill("//input[@placeholder='Enter UAN No.']", "1025456352");
	        
	        //EPF No.
	        page.fill("//input[@placeholder='Enter EPF No.']", "7845125456");
	        
	        //ESIC No.
	        page.fill("//input[@placeholder='Enter ESIC No.']", "4545656585");
	        
	        //CTC
	        page.fill("//input[@name='ctc']", "240000");
	        
	        //Medical Insurance
	        page.fill("//input[@name='Medical_insurance']", "2500");
	        
	        //Save Button
	        page.click("(//button[@type=\"primary\"])[3]");


	}

}
