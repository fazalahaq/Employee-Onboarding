package EcareCreate;

import java.util.List;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Main {

		public static void main(String[] args) throws InterruptedException {
			Playwright playwright = Playwright.create();
			Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setArgs(List.of("--start-maximized")));
			BrowserContext context = browser.newContext(new Browser.NewContextOptions().setViewportSize(null));		
			Page page = context.newPage();	
			page.navigate("https://devui-ecare.mightcode.com/login");
			
			//Login
	        page.fill("//input[@id='basic_email']","hrm1");
	        page.fill("//*[@id=\"basic_password\"]","Test@123");
	        page.click("//button[@type=\"submit\"]");	        
	       	        
	       // String DOB = "04/04/2001";
	        String name = "Priyanka Singh chauhan";
	        String MobilePer = "9450337191";
	        String emailPer = "Priyankachauhan@gmail.com";
	        String emailOff = "Priyankachauhan@mightcode.com";
	        String UAN = "1059183576";
	        String EPF = "33330333";
	        String ESIC = "44844444";
	        String CTC = "270000";
	        String Medical = "1800";
	        String IFSC = "HDFC0000412";
	        String AccNo = "22334455667";
	        String ReAccNo = "22334455667";
	        
	        Personal_Details PerDel = new Personal_Details();
	        PerDel.personal(page, name, MobilePer,emailPer );
	        Thread.sleep(2000);
	        
	        Professional_details ProfDel = new Professional_details();
	        ProfDel.professional(page, emailOff, name);
	        
	        Salary sal = new Salary();
	        sal.salary(page, UAN, EPF, ESIC, CTC, Medical);
	        
	        Bank_details bnk = new Bank_details();
	        bnk.bank(page, IFSC, AccNo, ReAccNo);	        
	}

}
