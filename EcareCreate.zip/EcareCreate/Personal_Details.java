package EcareCreate;

import java.nio.file.Path;
import com.microsoft.playwright.Page;

public class Personal_Details {

	public void personal(Page page ,String name, String MobilePer,String emailPer) throws InterruptedException {             
            //Register the employee
		Thread.sleep(3000);
			page.reload();
			
          //*[contains(text(), 'Add New Employee')]
            page.click("//*[@href=\"/hr/employee-listing\"]"); //click on employee at side menu
            page.click("//*[contains(text(), 'Add New Employee')]");
            
            //Upload Image profile
            page.locator("(//*[contains(text(), \"Browse\")])[1]").setInputFiles(Path.of("C:\\Users\\Unicode\\Downloads\\Test\\image.png"));
            
            page.fill("//*[@name=\"name\"]", name);
            
            //DOB
            page.click("(//*[@placeholder='Select Date'])[1]");//Click on calendar
            page.click("//*[@aria-label=\"year panel\"]"); //Click on year
            page.click("//*[@class=\"ant-picker-super-prev-icon\"]"); //click on backward icon to choose 1900 year
            page.click("//*[@title=\"1998\"]"); //selected year 1998
            page.click("//*[@title=\"1998-07\"]"); //selected the month July
            page.click("//*[@title=\"1998-07-05\"]");
            
            //Gender           
            //page.locator("(//input[@type='search'])[1]").clear();
            //page.wait(2000);
            page.click("(//input[@type='search'])[1]");//click on gender dropdown 
//            
            //page.click("//*[contains(text(),'Male')]");
            Thread.sleep(2000);
            //page.click("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]");
          //page.click("//div[@title='Male']//div[@class='ant-select-item-option-content']"); //click on options <Male>
          //page.click("(//div/div/div/div[2]/div/div/div[2])[2]");
          //page.click("(//*[@class=\"ant-space-item\"])[4]");           
            page.click("(//*[@class='ant-space-item'])[4]");
            
            //Marital status
           page.fill("(//input[@type='search'])[2]", "unmarried");
           page.keyboard().press("Enter");
            
//            //Contact
            page.fill("//*[@placeholder=\"Enter Number\"]", MobilePer);
            page.fill("//*[@placeholder=\"Enter Email\"]", emailPer);           
            
            //Blood group
            page.click("(//input[@type='search'])[4]");
            page.keyboard().press("Enter");
                  
            //father name salutation
            page.fill("(//input[@type='search'])[5]", "Dr.");
            page.fill("//input[@placeholder=\"Enter Father’s Name\"]","Mukesh Kumar Gupta");
            
            //Enter the Address
            page.fill("(//*[@placeholder=\"Enter Full Address\"])[1]", "508/13, New Hyderabad, Lucknow, 226007");
            
            //CheckBox
            page.click("//input[@name='is_address_same']");
            
            //Signature
            page.locator("//*[@for=\"upload-signature\"]").setInputFiles(Path.of("C:\\Users\\Unicode\\Downloads\\Test\\image.png"));
            
            //Upload Document
            page.fill("(//input[@type='search'])[8]", "Aadhaar");
            page.keyboard().press("Enter");
            page.fill("//*[@name=\"document_number\"]", "652452158545");
            page.locator("//span[@class=\"ant-upload\"]/input").setInputFiles(Path.of("C:\\Users\\Unicode\\Downloads\\Test\\image.png"));
            page.click("(//*[@aria-label=\"plus\"])[2]");
            Thread.sleep(2000);
            
            //Save The Employee
            //page.click("//button[@type='primary']");
            page.click("(//button[@type='primary'])[2]");
            Thread.sleep(2000);
                       
//         // Fill Aadhaar number
//            String aadhaarNumber = "672194578654"; // Aadhaar number
//            page.fill("//input[@placeholder='Enter Doc. No.']", aadhaarNumber);
//            
//            // Assertion to check Aadhaar number length
//            if (aadhaarNumber.length() != 12) {
//            	System.out.println("Aadhaar number must be exactly 12 digits. Provided: " + aadhaarNumber);
//            }
//            
//            // If you want to check if it's numeric
//            if (!aadhaarNumber.matches("\\d{12}")) {
//            	System.out.println("Aadhaar number must be numeric and exactly 12 digits. Provided: " + aadhaarNumber);
//          }
            

    }
}
